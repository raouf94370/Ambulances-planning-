# Ambulances Planning — V1

Première version fonctionnelle de l'application web de planning et de régulation.

## Fonctionnalités V1
- Tableau de bord / planning quotidien
- Navigation Planning, Transports, Patients, Ambulances, Chauffeurs
- Recherche globale
- 5 ambulances
- Gestion de chauffeurs
- Gestion de patients
- Statuts des transports, véhicules et chauffeurs
- Transports aller-retour
- Navigation jour précédent / jour suivant
- Interface responsive optimisée pour tablette Android
- Interface entièrement en français

## Lancer le projet

```bash
npm install
npm run dev
```

Puis ouvrir l'adresse indiquée par Vite.

## Suite prévue

La V1 utilise des données de démonstration en mémoire. La prochaine étape consiste à brancher une base de données, l'authentification, la persistance des transports, les récurrences et les règles métier de régulation.
